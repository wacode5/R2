tsne.Wiki <-
function(x, ...){
Rtsne(x, ...)
}
